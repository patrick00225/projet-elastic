<?php
echo "Bonjour, je suis un script PHP !";
error_log("fgfgfghhgf")
?>