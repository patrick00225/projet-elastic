<?php
echo "Bonjour, je suis un script PHP2.0 !";
error_log("fgfgfghhgf")
?>